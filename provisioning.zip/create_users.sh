#!/bin/bash

exec > /tmp/bla.txt 2>&1

# Check if the required arguments are provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <json_file>"
    exit 1
fi

# Read the JSON file
json_file=$1
users=$(jq -c '.users[]' $json_file)

# Folder to store SSH key pairs
key_folder="/data/users"

# Create the folder if it doesn't exist
sudo mkdir -p $key_folder

# Loop through each user in the JSON file
for user in $users; do
    username=$(echo $user | jq -r '.username')
    ssh_key_path="$key_folder/$username"

    # Create user
    sudo adduser --disabled-password --gecos "" $username

    # Generate SSH key pair
    sudo -u $username ssh-keygen -t rsa -b 2048 -f $ssh_key_path -N ""

    # Display the public key
    echo "Public key for $username:"
    cat "${ssh_key_path}.pub"
done
